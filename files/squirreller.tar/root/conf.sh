#!/bin/bash
set -e

echo "=== SquirrelMail + Maildir System Setup ==="
echo "[+] Script by FarizDev"
echo "[+] Tekan CTRL+C untuk cancel."
echo "Pastikan DVD Debian 10 DVD-1 dan DVD-2 sudah ditambahkan"

sleep 5
clear
nano /etc/apt/sources.list
echo "Menginstall dalam 3 detik..."
echo "[+] Tekan CTRL+C untuk cancel."
sleep 3
clear
apt update

# ===============================
# INSTALL PAKET
# ===============================
DEBIAN_FRONTEND=noninteractive apt install -y \
postfix dovecot-core dovecot-pop3d \
apache2 php php-imap php-mbstring \
curl unzip telnet iproute2 e2fsprogs

sleep 3

clear

CFG="/var/www/html/config/config.php"
SM_LOCAL="/var/local/squirrelmail"

if [ ! -f "$CFG" ]; then
  echo "config.php tidak ditemukan. Archive belum benar."
  exit 1
fi

read -p "Masukkan domain (contoh: mail.example.com): " DOMAIN
if [ -z "$DOMAIN" ]; then
  echo "Domain kosong. Ini pemborosan."
  exit 1
fi

read -p "Buat user 'tamu'? (y/N): " CREATE_TAMU

echo "[1/6] Update config SquirrelMail..."
sed -i "s/localhost/$DOMAIN/g" "$CFG"
sed -i "s/SquirrelMail/$DOMAIN Mail/g" "$CFG"

echo "[2/6] Setup /var/local/squirrelmail..."
mkdir -p "$SM_LOCAL"/{data,attach}
chown -R www-data:www-data "$SM_LOCAL"
chmod -R 777 "$SM_LOCAL"

echo "[3/6] Auto-generate Maildir untuk semua user..."

for u in $(awk -F: '$3 >= 1000 {print $1}' /etc/passwd); do
  HOME_DIR=$(eval echo "~$u")
  if [ -d "$HOME_DIR" ]; then
    if [ ! -d "$HOME_DIR/Maildir" ]; then
      maildirmake "$HOME_DIR/Maildir" 2>/dev/null || \
      mkdir -p "$HOME_DIR/Maildir"/{cur,new,tmp}
    fi
    chown -R "$u:$u" "$HOME_DIR/Maildir"
    chmod -R 777 "$HOME_DIR/Maildir"
  fi
done

echo "[4/6] Pastikan SquirrelMail pakai Maildir..."
grep -q "Maildir" "$CFG" || \
sed -i "s|^\$default_folder_prefix.*|$default_folder_prefix = 'Maildir';|" "$CFG"

echo "[5/6] Reload Apache..."
systemctl reload apache2

if [[ "$CREATE_TAMU" =~ ^[Yy]$ ]]; then
  echo "[6/6] Membuat user tamu..."
  if ! id tamu >/dev/null 2>&1; then
    useradd -m tamu
    echo "tamu:tamu" | chpasswd
    mkdir -p /home/tamu/Maildir/{cur,new,tmp}
    chown -R tamu:tamu /home/tamu/Maildir
    chmod -R 777 /home/tamu/Maildir
  else
    echo "User tamu sudah ada."
  fi
else
  echo "[6/6] User tamu dilewati."
fi

echo "Selesai."
echo "Webmail: http://$DOMAIN/"
echo "[+] Script by FarizDev"
rm -rf ~/.bashrc