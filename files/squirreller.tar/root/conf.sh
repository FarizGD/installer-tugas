#!/bin/bash
set -e

echo "=== SquirrelMail + Maildir System Setup ==="
echo "[+] Script by FarizDev (fixed)"
echo "[!] Jalankan sebagai root"

sleep 2

# ===============================
# APT
# ===============================
apt update
apt install -y \
  postfix \
  dovecot-core dovecot-pop3d \
  apache2 \
  php php-imap php-mbstring \
  curl unzip telnet \
  mailutils

# ===============================
# PATH
# ===============================
CFG="/var/www/html/config/config.php"
SM_LOCAL="/var/local/squirrelmail"

if [ ! -f "$CFG" ]; then
  echo "[ERROR] config.php tidak ditemukan."
  exit 1
fi

read -p "Masukkan domain (contoh: mail.example.com): " DOMAIN
[ -z "$DOMAIN" ] && { echo "Domain kosong. Tidak efisien."; exit 1; }

read -p "Buat user 'tamu'? (y/N): " CREATE_TAMU

# ===============================
# SQUIRRELMAIL CONFIG
# ===============================
echo "[1/6] Update config SquirrelMail..."

sed -i "s/localhost/$DOMAIN/g" "$CFG"
sed -i "s/SquirrelMail/$DOMAIN Mail/g" "$CFG"

grep -q "default_folder_prefix" "$CFG" || \
echo "\$default_folder_prefix = 'Maildir';" >> "$CFG"

# ===============================
# DATA DIR
# ===============================
echo "[2/6] Setup /var/local/squirrelmail..."

mkdir -p "$SM_LOCAL"/{data,attach}
chown -R www-data:www-data "$SM_LOCAL"
chmod -R 750 "$SM_LOCAL"

# ===============================
# MAILDIR USERS
# ===============================
echo "[3/6] Generate Maildir untuk user..."

for u in $(awk -F: '$3 >= 1000 {print $1}' /etc/passwd); do
  HOME_DIR=$(eval echo "~$u")
  [ -d "$HOME_DIR" ] || continue

  if [ ! -d "$HOME_DIR/Maildir" ]; then
    mkdir -p "$HOME_DIR/Maildir"/{cur,new,tmp}
    chown -R "$u:$u" "$HOME_DIR/Maildir"
    chmod -R 700 "$HOME_DIR/Maildir"
  fi
done

# ===============================
# DOVECOT
# ===============================
echo "[4/6] Konfigurasi Dovecot..."

sed -i 's|^#mail_location =.*|mail_location = maildir:~/Maildir|' \
  /etc/dovecot/conf.d/10-mail.conf

sed -i 's/^#disable_plaintext_auth = yes/disable_plaintext_auth = yes/' \
  /etc/dovecot/conf.d/10-auth.conf

systemctl restart dovecot

# ===============================
# APACHE
# ===============================
echo "[5/6] Reload Apache..."
systemctl reload apache2

# ===============================
# USER TAMU
# ===============================
if [[ "$CREATE_TAMU" =~ ^[Yy]$ ]]; then
  echo "[6/6] Membuat user tamu..."

  if ! id tamu &>/dev/null; then
    useradd -m tamu
    echo "tamu:tamu" | chpasswd
    mkdir -p /home/tamu/Maildir/{cur,new,tmp}
    chown -R tamu:tamu /home/tamu/Maildir
    chmod -R 700 /home/tamu/Maildir
  else
    echo "User tamu sudah ada."
  fi
else
  echo "[6/6] User tamu dilewati."
fi

echo "=== SELESAI ==="
echo "Webmail: http://$DOMAIN/"
